#include<iostream>
using namespace std;
//First create a class
class set
{
private:
public:
    int hour_one, hour_two;
    int minute_one, minute_two;
    int second_one, second_two;
    //Making default constructor
    set()
    {
        this->hour_one = 12;
        this->minute_one = 00;
        this->second_one = 00;
        this->hour_two = 00;
        this->minute_two = 00;
        this->second_two = 00;

    }
    void head_clock(int h = 1)
    {
        if (h == 1)
        {
            if (second_one / 60 > 0)
            {
                second_one = second_one % 60;
                minute_one++;
            }
            if (minute_one / 60 > 0)
            {
                minute_one = minute_one % 60;
                hour_one++;
            }
            if (hour_one / 12 > 0)
            {
                hour_one = hour_one % 12;
                if (hour_one == 0)
                {
                    hour_one = 12;
                }
            }
        }
        if (h == 2)
        {
            if (second_two / 60 > 0)
            {
                second_two = second_two % 60;
                minute_two++;
            }
            if (minute_two / 60 > 0)
            {
                minute_two = minute_two % 60;
                hour_two++;
            }
            if (hour_two / 24 > 0)
            {
                hour_one = hour_one % 24;
            }
        }
    }
    void display() {
        printf("\nTime 1: %02d:%02d:%02d\n", hour_one, minute_one, second_one);
        printf("Time 2: %02d:%02d:%02d\n\n", hour_two, minute_two, second_two);
    }
    void increase_hour()
    {
        hour_one++;
        hour_two++;
        head_clock(1);
        head_clock(2);
    }
    void increase_minute() {
        minute_one++;
        minute_two++;
        head_clock(1);
        head_clock(2);
    }
    void standby_second() {
        second_one++;
        second_two++;
        head_clock(1);
        head_clock(2);

    }
    void increment_second() {
        second_one++;
        second_two++;
        head_clock(1);
        head_clock(2);
    }
};
int main() {
    set s;
    int a, b, c, d = 1;
    while (d > 0)
    {
        s.display();
        cout << "Press Button?(1:yes,2:no):" << endl;
        cin >> a;
        if (a == 1)
        {
            cout << "Choose option\n1.Add Time\n2.EXIT\nEnter 1 or 2:";
            cin >> b;
            if (b == 1)
            {
                cout << "Choose option\n1. Add 1 hour\n2. Add 1 minute\n3. Add 1 second\nEnter 1 or 2 or 3: ";
                cin >> c;
                switch (c)
                {
                case 1: s.increase_hour(); break;
                case 2: s.increase_minute(); break;
                case 3: s.increment_second();
                }
            }
            if (b == 2)
            {
                d = d - 1;
            }
        }
        else if (a == 2)
        {
            s.increment_second();
            s.standby_second();
        }
    }
}
